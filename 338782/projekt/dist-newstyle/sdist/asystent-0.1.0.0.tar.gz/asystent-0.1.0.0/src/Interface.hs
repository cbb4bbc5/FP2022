{-# LANGUAGE GeneralisedNewtypeDeriving, GADTs #-}
module Interface(topLoop,proofLoop,MonadRL(..),MonadLex(..),LexState) where
    import Formula
    import Logic
    import Proof
    import Monads
    import Control.Monad.State
    import Control.Monad.Reader
    import qualified Data.Map as Map
    import Control.Applicative
    import System.IO
    
    


        

    instance Show With where
        showsPrec 0 (GetString s) s1 = s ++ s1
        showsPrec 0 (GetProof (pr,_,Nothing)) s1 = show pr ++ s1
        showsPrec 0 (GetProof (_,_,Just thm)) s1 = show thm ++ s1
        showsPrec 0 (GetFormat f) s1 = show f ++ s1
        showsPrec _ w s1 = "(" ++ show w ++ ")" ++ s1

    reservedTop = ["let", "proof","exit","save"]
    reservedProof = ["let","trivial", "apply", "split", "intro", "next", "exit", "add", "choose", "get", "gets"]
    reservedTheorem = ["forallI" , "forallE", "forallEs", "andI", "andR", "andL", "topI", "bottomE",
                    "orR", "orL", "orE", "impliesI", "impliesE", "iffI", "iffE", "existsI", "existsE", "subst"]

    
   

    
    readProof = do
        name <- getLex
        xs <- reading reads <|> return []
        f <- input FormulaF
        let pr = proof xs f & trivial
        putMap name $ GetProof (pr,[],qedM pr)
        runReaderT proofLoop name `catchError` \e -> writeLine e

    topLoop = do
        command <- getLex
        case command of
            "proof" -> readProof >> topLoop
            "let"  -> do
                name <- getLex
                "=" <- getLex
                let isFormat = do
                        f <- (reading reads <&> GetFormat)
                        let isString = do
                                GetFormat (LitA s) <- return f
                                return $ GetString s
                        ff <- isString <|> f
                putMap name ff
                topLoop
            "exit" -> return ()
            "save" -> do
                name <- getLex
                content <- look
                liftIO $ writeFile name content
                topLoop
    
    proofLoop = do
        writeLine $ show
        command <- getLex
        case command of
            "apply" -> 
            "trivial" ->
            "split" ->
            "next" ->
            "add" ->
            "choose" ->
            "get" ->
            "gets" ->
            "intro" ->
            "proof" ->
            "let" ->
            "exit" ->
