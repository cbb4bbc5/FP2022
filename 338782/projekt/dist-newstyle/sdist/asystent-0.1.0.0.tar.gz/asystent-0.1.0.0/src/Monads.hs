{-# LANGUAGE GADTs #-}
module Monads(With(..)) where
    import Control.Applicative
    import Control.Monad
    import qualified Data.Map as Map
    import qualified Data.List as List
    import Control.Monad.Trans
    import Control.Monad.State
    import Control.Monad.Accum
    import Proof
    import Formula
    import Logic


    data With =
          GetString String
        | GetProof (Proof,[String],Maybe Theorem)
        | GetFormat AnyFormat

    newtype MapState m a = MState (StateT (Map.Map String With) m a)
        deriving (Functor, Applicative, Monad,Alternative, MonadPlus, MonadFail, MonadTrans, MonadIO, MonadRL , MonadLex, MonadAccum)
    newtype HisAccum m a = HAccum (AccumT String m a)
        deriving (Functor, Applicative, Monad,Alternative, MonadPlus,MonadFail,MonadTrans, MonadIO, MonadLex)
    newtype LexState m a = LexState {runLex :: StateT String m a}
        deriving (Functor,Applicative,Monad,MonadIO,MonadTrans,MonadRL,MonadInput,Alternative,MonadPlus,MonadFail,MonadAccum)

    class Monad m => MonadRL m where
        readLine :: m String
        writeLine :: String -> m ()
    class Monad m => MonadMap m where
        getMap :: String -> m (Maybe With)
        putMap :: String -> With -> m ()
    class MonadRL m => MonadLex m where
        getLex :: m String
        reading :: Read a => ReadS a -> m a

    
    instance MonadRL m => MonadRL (AccumT String m) where
        readLine = lift readLine
        writeLine = lift . writeLine
    instance MonadLex m => MonadLex (AccumT String m) where
        getLex = lift getLex
        reading = lift . reading
    instance MonadRL m => MonadRL (StateT s m) where
        readLine = lift readLine
        writeLine = lift . writeLine
    instance MonadMap m => MonadMap (StateT s m) where
        getMap = lift . getMap
        putMap  = (.) lift . putMap 
    instance MonadLex m => MonadLex (StateT s m) where
        getLex = lift getLex
        reading = lift . reading

    instance Monad m => MonadMap (MapState m) where
        getMap s = MState $ fmap (Map.lookup s) get
        putMap s w = MState $ modify $ Map.insert s w

    instance MonadRL m => MonadRL (HisAccum m) where
        readLine = HAccum $ do
            l <- readLine
            add $ '\n' : l
            return l
        writeLine = lift . writeLine

    instance (MonadPlus m,MonadFail m,MonadLex m,MonadMap m) => MonadInput (MapState m) where
        input format = 
          let fromMap = do
                Just x <- getLex >>= getMap
                case (x, format) of
                    (GetString f,FormulaF) -> return $ read f
                    (GetString t,TermF) -> return $ read t
                    (GetString s,StringF) -> return s
                    _ -> mzero
            in MState $ fromMap <|> case format of
                FormulaF -> reading reads
                StringF -> reading reads
                TermF -> reading reads
                _ -> mzero
        inputFormat =  
          let fromMap = do
                x <- getLex >>= getMap
                case x of
                    Just (GetFormat f) -> return f
                    _ -> mzero
            in MState $ fromMap <|> reading reads

    instance MonadRL IO where
        readLine = getLine
        writeLine = putStrLn
    instance (MonadRL m,MonadPlus m) => MonadLex (LexState m) where
        getLex = LexState $ do
                s <- get
                case lex s of
                    [] -> mzero
                    [("","")] -> readLine >>= put >> runLex getLex
                    ((s1,s2):_) -> put s2 >> return s1
        reading rea = LexState $ do
            str <- get
            case rea str of
                [] -> mzero
                ((x,xs):_) -> put xs >> return x
