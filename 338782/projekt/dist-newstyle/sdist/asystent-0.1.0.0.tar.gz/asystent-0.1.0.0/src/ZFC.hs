module ZFC(ZFC(..)) where
    data ZFC =
          Ext -- 
        | Reg --
        | Spec --
        | Pair --
        | Union --
        | Replace --
        | Inf --
        | Power -- AX. EPX. Apx. px @ PX <=> Ax. x @ px -> x @ X
        | Choise -- AX.(AA.A @ X -> Ea.a @ A) -> EY. AA. A @ X -> Ey! y @ Y & y @ A