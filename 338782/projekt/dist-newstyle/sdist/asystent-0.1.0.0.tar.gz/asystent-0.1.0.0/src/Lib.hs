module Lib
    (
        module Formula,
        module Axiom,
        module Logic,
        module Proof,
        module Data.Function
    ) where
    import Formula
    import Axiom
    import Logic
    import Proof
    import Data.Function
    
