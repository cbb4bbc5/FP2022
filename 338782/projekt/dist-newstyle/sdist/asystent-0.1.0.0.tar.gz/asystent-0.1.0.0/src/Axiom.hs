
module Axiom (Axiom(axiom)) where
    import Formula
    class Axiom a where
        axiom :: a -> Formula


