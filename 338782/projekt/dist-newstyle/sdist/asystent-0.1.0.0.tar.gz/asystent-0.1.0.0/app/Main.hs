module Main (main) where


main :: IO ()
main = error ""
